# Open Model Router — Landing page concept

## Contenu

- `index.html` : landing page responsive autonome (HTML, CSS et JavaScript dans un seul fichier).
- `hero-preview.png` : capture du premier écran sur desktop (1440 px).
- `desktop-preview.png` : capture de la page complète.
- `mobile-above-fold.png` : capture du premier écran mobile (390 px).
- `mobile-full-preview.png` : capture de la page complète sur mobile.

## Ouvrir la page

Ouvrir `index.html` dans un navigateur. Pour un serveur local :

```bash
python3 -m http.server 8000
```

Puis visiter http://localhost:8000.

## Identité visuelle

Une identité propre à Open Model Router, sans reprise de celle de Float : fond noir-vert, vert citron lumineux, pictogramme de branchement monoline, langage graphique inspiré de la visualisation de flux et des outils développeur.

## Interactions

- Sélecteur de tâches (Quick answer / Everyday chat / Deep reasoning / Visual analysis), qui modifie l'intention, la logique de sélection, le résultat et le schéma du hero.
- Menu mobile accessible.
- FAQ native accessible au clavier.
- Bouton permettant de copier le snippet TypeScript.
- Navigation par ancres.

## Important avant mise en production

La démo est simulée et n'appelle aucune API d'IA. Le snippet TypeScript représente une API **conceptuelle**, pas un SDK existant. Remplacer les textes de promesse, les exemples de modèles, les URLs et la logique d'intégration par les fonctionnalités effectivement disponibles dans le projet.

Les polices externes (Google Fonts) sont optionnelles ; des polices système servent de repli si elles ne chargent pas. Aucune librairie JavaScript n'est nécessaire.
